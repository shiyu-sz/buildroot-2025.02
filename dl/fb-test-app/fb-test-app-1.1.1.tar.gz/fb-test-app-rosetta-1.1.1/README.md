# Purpose
some tools for testing framebuffer.

Come from fb-test-app-rosetta-1.1.0.tar.gz.

# Build
```
$ make
```
