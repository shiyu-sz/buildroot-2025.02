# SPDX-License-Identifier: MIT

"""
test_flit - Example flit package
"""

__version__ = '1.0.0'
