flit_core
---------

This provides a `PEP 517 <https://peps.python.org/pep-0517/>`_ build backend
for packages using `Flit <https://pypi.org/project/flit/>`_.  The only public
interface is the API specified by PEP 517, at ``flit_core.buildapi``.

See the `Flit documentation <https://flit.pypa.io/en/stable/>`_ for more
information.
