Distribution with a simple C extension that calculates Fibonacci numbers.
