# -*- coding: utf-8 -*-
from random import randint

def is_valid_grammar(sentence):
    if randint(0, 10) < 2:
        return False
    else:
        return True
