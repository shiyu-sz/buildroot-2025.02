# brcmfmac_sdio-firmware-rpi

Alternative source for RPi/Broadcom/Cypress/Synaptics firmwares:

WiFi: https://github.com/RPi-Distro/firmware-nonfree/tree/bookworm/debian/config/brcm80211  
Bluetooth: https://github.com/RPi-Distro/bluez-firmware/tree/bookworm/debian/firmware

# License

License: Redistributable. See LICENSE for details.
