print('Hello world!')
