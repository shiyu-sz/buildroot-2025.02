#include"extractor.h"

int func2(void) {
    return 2;
}
