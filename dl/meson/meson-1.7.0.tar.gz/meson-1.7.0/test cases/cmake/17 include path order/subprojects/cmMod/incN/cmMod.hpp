// cmMod.hpp (N)
#pragma once

#error "cmMod.hpp in incN must not be included"
