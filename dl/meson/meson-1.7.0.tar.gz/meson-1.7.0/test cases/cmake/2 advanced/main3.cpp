extern void slib();

int main() {
  slib();
  return 0;
}
